####（加）更新每条河道的磁力地图，更新8
source_here = function(filename,nowdir = dirname(rstudioapi::getSourceEditorContext()$path)){
  fulldir = paste(nowdir,'/',filename,sep = '');  source(fulldir, encoding = encoding)}

updataChannelMagneticDatabase = function(
  tmyPtsRot,
  x.min ,
  y.min ,
  x.max ,
  y.max ,
  grid_size,
  nowLocation,
  channelWellsXY
){
  library("dplyr")
  distanceToChannelWells.vector = sqrt((nowLocation$X - channelWellsXY$X)**2 + ( nowLocation$Y- channelWellsXY$Y)**2)###生成当前位置与河道点的距离向量
  minDistanceToChannelWells = min(distanceToChannelWells.vector)
  temporarychannelWells <- cbind(channelWellsXY,distanceToChannelWells.vector)####生成临时的data(加上了距离向量)
  df3 <- arrange(temporarychannelWells,distanceToChannelWells.vector)###按照某一列排序，提取某一行，默认升序排列使用arrange函数需要下载dplyr包
  AlreadyChannelScattersXYH_add <-df3[1,]###提取最小的那一行
  if(minDistanceToChannelWells<safetydistance){if(AlreadyChannelScattersXYH_add[['isChannel']] == 10){
   ###对整个游走过的河道判断吸引与
    v<-
    
    
    
    
     oilcomparechannel1 = tmyPtsRot[tmyPtsRot$isChannel==20,]
    oilcomparechannel1.subset<-subset(oilcomparechannel1, H<AlreadyChannelScattersXYH_add$H)
    tmyPtsRot[c(oilcomparechannel1.subset$Well.identifier),][tmyPtsRot[c(oilcomparechannel1.subset$Well.identifier),] == "20"] = 0
    #####不符合油水矛盾时输出临时的磁力地图
    x.min = min(tmyPtsRot$X)
    y.min = min(tmyPtsRot$Y)
    x.max = max(tmyPtsRot$X)
    y.max = max(tmyPtsRot$Y)
    grid_size = round((x.max - x.min)/50)
    x.seq = seq(x.min,x.max,length.out = (x.max - x.min)/grid_size)
    y.seq = seq(y.min,y.max,length.out = (y.max - y.min)/grid_size)
    tmagneticDatabase = Build_magneticDatabase(myPtsRot = tmyPtsRot)
    ####结束输出临时磁力地图
  }else {
    watercomparechannel1 = tmyPtsRot[tmyPtsRot$isChannel==10,]
    watercomparechannel1.subset<-subset(watercomparechannel1, H>AlreadyChannelScattersXYH_add$H)
    tmyPtsRot[c(watercomparechannel1.subset$Well.identifier),][tmyPtsRot[c(watercomparechannel1.subset$Well.identifier),] == "10"] = 0
    #####不符合油水矛盾时输出临时的磁力地图
    x.min = min(tmyPtsRot$X)
    y.min = min(tmyPtsRot$Y)
    x.max = max(tmyPtsRot$X)
    y.max = max(tmyPtsRot$Y)
    grid_size = round((x.max - x.min)/50)
    x.seq = seq(x.min,x.max,length.out = (x.max - x.min)/grid_size)
    y.seq = seq(y.min,y.max,length.out = (y.max - y.min)/grid_size)
    tmagneticDatabase = Build_magneticDatabase(myPtsRot = tmyPtsRot)
    ####结束输出临时磁力地图
  }
  }
  
  
  
  
}
  
  
  
  
  
  
  
  
  
  
  
















{
library("dplyr")
distanceToChannelWells.vector = sqrt((nowLocation$X - channelWellsXY$X)**2 + ( nowLocation$Y- channelWellsXY$Y)**2)###生成当前位置与河道点的距离向量
minDistanceToChannelWells = min(distanceToChannelWells.vector)
temporarychannelWells <- cbind(channelWellsXY,distanceToChannelWells.vector)####生成临时的data(加上了距离向量)
df3 <- arrange(temporarychannelWells,distanceToChannelWells.vector)###按照某一列排序，提取某一行，默认升序排列使用arrange函数需要下载dplyr包
AlreadyChannelScattersXYH_add <-df3[1,]###提取最小的那一行
###判断河道井是油井还是水井
if(minDistanceToChannelWells<safetydistance){if(AlreadyChannelScattersXYH_add[['isChannel']] == 10){
  oilcomparechannel1 = tmyPtsRot[tmyPtsRot$isChannel==20,]
  oilcomparechannel1.subset<-subset(oilcomparechannel1, H<AlreadyChannelScattersXYH_add$H)
  tmyPtsRot[c(oilcomparechannel1.subset$Well.identifier),][tmyPtsRot[c(oilcomparechannel1.subset$Well.identifier),] == "20"] = 0
  #####不符合油水矛盾时输出临时的磁力地图
  x.min = min(tmyPtsRot$X)
  y.min = min(tmyPtsRot$Y)
  x.max = max(tmyPtsRot$X)
  y.max = max(tmyPtsRot$Y)
  grid_size = round((x.max - x.min)/50)
  x.seq = seq(x.min,x.max,length.out = (x.max - x.min)/grid_size)
  y.seq = seq(y.min,y.max,length.out = (y.max - y.min)/grid_size)
  tmagneticDatabase = Build_magneticDatabase(myPtsRot = tmyPtsRot)
  ####结束输出临时磁力地图
  }else {
  watercomparechannel1 = tmyPtsRot[tmyPtsRot$isChannel==10,]
  watercomparechannel1.subset<-subset(watercomparechannel1, H>AlreadyChannelScattersXYH_add$H)
  tmyPtsRot[c(watercomparechannel1.subset$Well.identifier),][tmyPtsRot[c(watercomparechannel1.subset$Well.identifier),] == "10"] = 0
  #####不符合油水矛盾时输出临时的磁力地图
  x.min = min(tmyPtsRot$X)
  y.min = min(tmyPtsRot$Y)
  x.max = max(tmyPtsRot$X)
  y.max = max(tmyPtsRot$Y)
  grid_size = round((x.max - x.min)/50)
  x.seq = seq(x.min,x.max,length.out = (x.max - x.min)/grid_size)
  y.seq = seq(y.min,y.max,length.out = (y.max - y.min)/grid_size)
  tmagneticDatabase = Build_magneticDatabase(myPtsRot = tmyPtsRot)
  ####结束输出临时磁力地图
  }
}
return(tmagneticDatabase)
}
  ###添加结束
##（用于检查生成的磁力地图是否更新）contour(x.seq,y.seq,matrix(tmagneticDatabase$Z,nrow = length(x.seq)))
  
  
  
  
  

  