#用于将一个向量归一化，即c(1,2,3,4,5) → c(0.00, 0.25, 0.50, 0.75, 1.00)
guiyihua = function(variable){
  new = (variable - min(variable))/(max(variable)-min(variable))
  # print(new)
  return(new)
}