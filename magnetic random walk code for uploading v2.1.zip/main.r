encoding = 'UTF-8'
###更新10+方案三
#准备，处理工作路径，导入必要程序包和函数：
#install.packages("http://xuzhougeng.top/static/RSQLite_2.2.1.zip",repos = NULL, type = "binary")
  nowdir = dirname(rstudioapi::getSourceEditorContext()$path);setwd(nowdir)
  setwd(nowdir)
  source_here = function(filename,nowdir = dirname(rstudioapi::getSourceEditorContext()$path)){
    fulldir = paste(nowdir,'/',filename,sep = '');  source(fulldir, encoding = encoding)}
  source_here('函数random_walk_2d，磁力随机行走函数.R')
  source_here("函数Build_magneticDatabase.R")
  source_here("函数rotation.R")
  source_here('函数addchannel.R')
  source_here('Function UpperLeftShift and LowerRightShift.R')
  library("dplyr")
  library(export)
  library(smoothr)
  library(ggplot2)
  library(SpatialExtremes)
#准备，处理工作路径，导入必要程序包和函数。

#创建 magneticDatabase and drwMapRot:========================================
  #基本设定与geometry：
    setwd(nowdir)
    myPts = readRDS('myPts in use of real case.rds')#0是非河道，10是油井，20是水井#注意列数要最简便那种
    myPts$Well.identifier = 1:length(myPts$Well.identifier)
    # myPts = read.csv('点位信息2（考虑油水矛盾）.csv')#0是非河道，10是油井，20是水井#注意列数要最简便那种
    set.seed(2)#2还可以；
  
  #设置一些参数：
    N.max = 100#最大游走步数
    rotationAngleInRadiansAnti_clockwise = 0 # pi/2#旋转的角度
    StepLength = 30#步长
    co.horizontal = 0#横向的偏置系数，默认是1/300;
    stabilityIndex = 1#稳定系数（降低随机性）
    safetyDistance = 50#距离非河道井的最小距离
    safetydistance = 50 ##油水保护
    DistanceForAvoidAlreadyTouch = 35
    AlreadyChanneloilScattersXYH = NULL####在oilprotection中的初始设置
    AlreadyChannelwaterScattersXYH = NULL####在oilprotection中的初始设置
    PointsOfThisPeriodall= NULL###初始，避免交叉
    nowzht =NULL ###给游走的点赋值addchannel子程序
    initialpoint = 12  #####给游走点赋值井点addchannel子程序
  #设置一些参数。
    
  #预处理和观察：
    col.plot = myPts$isChannel
    col.plot[col.plot==0]="grey"
    col.plot[col.plot==20] = "blue"
    col.plot[col.plot== 10] = "red"
    plot(myPts$X,myPts$Y,col=col.plot,pch=19,asp = 1)

    myPtsRot = myPts
    myPtsRot[,2:3] = rotation(myPtsRot[,2:3],rotationAngleInRadiansAnti_clockwise)
    tmyPtsRot = myPtsRot######（加，更新不符合油水矛盾的井点）
    plot(myPtsRot$X,myPtsRot$Y,col=col.plot,pch=19,asp = 1)
    ####高程底图信息start=====================http://127.0.0.1:10913/graphics/plot_zoom_png?width=1536&height=814
    data.now = myPtsRot
    index.nulls = which(is.na(data.now$Y))
    data.now = data.now[!is.na(data.now$Y),]
    x = data.now$X
    y = data.now$Y
    z = data.now$H
    Well.identifier = data.now$Well.identifier
    original.xyz.pts = data.frame(x,y,z,Well.identifier)
    xo = seq(min(x),max(x),length=100)
    yo = seq(min(y), max(y), length=100)
    xlim = range(6000, 9500)
    ylim = range(5500, 8000)
    #use akima:
    inter_lin = akima::interp(x,y,z,xo = xo,
                              yo = yo, linear=FALSE, extrap = TRUE, duplicate =TRUE)
    xygrid1 = expand.grid(x = xo, y = yo)
    xygrid1$z = as.vector(inter_lin$z)
    xygrid1$z[xygrid1$z<0] = 0
    all(inter_lin$z == matrix(xygrid1$z,nrow = length(yo)))
    #####高程底图信息end=======================
    contour(xo,yo,matrix(xygrid1$z,nrow = length(yo)),add = TRUE)
  #预处理和观察。
    
  #制作drwMapRot：
    drwMapRot = list()
    drwMapRot[['baseWellsXY']] = myPtsRot
    drwMapRot[['channelWellsXY']] = myPtsRot[myPtsRot$isChannel==20|myPtsRot$isChannel==10,]###加一个或语言
    drwMapRot[['non_channelWellsXY']] = myPtsRot[myPtsRot$isChannel==0,]
    basechannel = drwMapRot$channelWellsXY  ###addchannel函数中作为勘探井
    #制作drwMapRot。
    
  #制作magneticDatabase：
    x.min = min(myPtsRot$X)
    y.min = min(myPtsRot$Y)
    x.max = max(myPtsRot$X)
    y.max = max(myPtsRot$Y)
    grid_size = round((x.max - x.min)/50)#StepLength 
    x.seq = seq(x.min,x.max,length.out = (x.max - x.min)/grid_size)
    y.seq = seq(y.min,y.max,length.out = (y.max - y.min)/grid_size)
    magneticDatabase = Build_magneticDatabase(myPtsRot = myPtsRot,
                                              x.min = x.min,
                                              y.min = y.min,
                                              x.max = x.max,
                                              y.max = y.max,
                                              grid_size = grid_size)
    tmagneticDatabase = magneticDatabase#(加，为了更新每次游走轨迹中不符合油水矛盾的实时磁力地图)
  
    #制作magneticDatabase。
    rr = tmagneticDatabase$X
    tt = tmagneticDatabase$Y
    gg = tmagneticDatabase$Z
    
    drawmyRot <- subset(myPtsRot,select=-Well.identifier)
    drawmyRot <- subset(drawmyRot,select=- H)
    names(drawmyRot)<-c("X","Y","Z")
    drawmyRot1 <- subset(drawmyRot,drawmyRot$Z=="0")
    drawmyRot2 <- subset(drawmyRot,drawmyRot$Z=="10")
    drawmyRot3 <- subset(drawmyRot,drawmyRot$Z=="20")
    ######需要单独运行，不可直接source
    date = substring(Sys.time(),1,10)
    dir.create(date)
    path.ggsave = paste(getwd(),'/',date,sep = '')
    v <- ggplot(tmagneticDatabase, aes(X, Y, z=Z))
    
    p11 = v + geom_contour_filled() + coord_equal() +
      geom_point(data = drawmyRot1, aes(X,Y), colour = 'grey', size = 1.5)+ 
      geom_point(data = drawmyRot2, aes(X,Y), colour = 'red', size = 1.5) + 
      geom_point(data = drawmyRot3, aes(X,Y), colour = 'blue', size = 1.5)
    ggsave('original magnetic database.jpg',plot = p11,width = 50*0.35,height = 30*0.35,units = 'cm'
           ,path = path.ggsave)
    
#随机游走（南北双方向）：start the loop===============================================================================
    PointsOfThisPeriod = list()
    PointsOfAlreadyChannelScattersXYH = list()
    for (i in 1:length(drwMapRot$channelWellsXY$Y)) {
      Southresult = random_walk_2d(  firstSource = drwMapRot$channelWellsXY[i,]
                                     ,N = N.max
                                     ,magneticDatabase = tmagneticDatabase
                                     ,drwMapRot = drwMapRot
                                     ,StepLength = StepLength
                                     ,co.horizontal = co.horizontal
                                     ,stabilityIndex = stabilityIndex
                                     ,safetyDistance = safetyDistance
                                     ,DistanceForAvoidAlreadyTouch = DistanceForAvoidAlreadyTouch
                                     ,OnlySouthward = TRUE
                                     ,MagneticRadius = 30
                                     ,tmyPtsRot = tmyPtsRot)
      Northresult = random_walk_2d(  firstSource = drwMapRot$channelWellsXY[i,]
                                     ,N = N.max
                                     ,magneticDatabase = tmagneticDatabase
                                     ,drwMapRot = drwMapRot
                                     ,StepLength = StepLength
                                     ,co.horizontal = co.horizontal
                                     ,stabilityIndex = stabilityIndex
                                     ,safetyDistance = safetyDistance
                                     ,DistanceForAvoidAlreadyTouch = DistanceForAvoidAlreadyTouch
                                     ,OnlyNorthward = TRUE
                                     ,MagneticRadius = 25
                                     ,tmyPtsRot = tmyPtsRot)
      num5 = i*1000
      PointsOfThisPeriod[[i]] = rbind(Northresult[length(Northresult$x):1,],Southresult)
       PointsOfThisPeriod2 = Hchannel(addchannel = PointsOfThisPeriod[[i]],
                                         xygrid1 = xygrid1,
                                         basechannel = basechannel,
                                         num5 = num5)
      PointsOfThisPeriodall = rbind(PointsOfThisPeriodall,PointsOfThisPeriod2)
      tmyPtsRot <- rbind(tmyPtsRot,PointsOfThisPeriodall)#注意列数要最简便那种
      tmyPtsRot = tmyPtsRot[!is.na(tmyPtsRot$X),]#very important!
      tmyPtsRot = tmyPtsRot[!is.na(tmyPtsRot$H),]
      num7 = dim(tmyPtsRot)[1]
      tmyPtsRot$Well.identifier<- c(1:num7)
      ####addchannel加
      drwMapRot = list()
      drwMapRot[['baseWellsXY']] = tmyPtsRot
      drwMapRot[['channelWellsXY']] = tmyPtsRot[tmyPtsRot$isChannel==20|tmyPtsRot$isChannel==10,]###加一个或语言
      drwMapRot[['non_channelWellsXY']] = tmyPtsRot[tmyPtsRot$isChannel==0,]
      ####addchannel加
      tmagneticDatabase = magneticDatabase###（加，每运行一次轨迹完成之后，重新回复原来的磁力地图，进行下一次的轨迹游走）
      points(rbind(Northresult,Southresult)[,c(1,2)],pch=19)
      ####（加）
    }
 #随机游走（南北双方向）。  
###后处理对已经游走完成但是独立的点进行粘连
    # saveRDS(PointsOfThisPeriod,'PointsOfThisPeriod.rds')
####粘连结束
    # PointsOfThisPeriod = readRDS('PointsOfThisPeriod.rds')    
#后处理：    
  contour(xo,yo,matrix(xygrid1$z,nrow = length(yo)),asp=1)
  points(myPtsRot$X,myPtsRot$Y,col=col.plot,pch=19)
  text(myPtsRot$X,myPtsRot$Y,
       labels=myPtsRot$Well.identifier,
       cex = 1)
  graph2ppt(file='井位图.ppt',height = 5, width = 10)
  for (i in 1:length(PointsOfThisPeriod)) {
    points(x = PointsOfThisPeriod[[i]]$x, 
           y = PointsOfThisPeriod[[i]]$y,
           col='black',
           cex = 0.25,
           lwd=8)
  }
  graph2ppt(file='plot1.ppt',height = 5, width = 10, append = F)
  for (i in 1:length(PointsOfThisPeriod)) {
    lines(x = PointsOfThisPeriod[[i]]$x, 
           y = PointsOfThisPeriod[[i]]$y,
           col='purple',
           cex = 0.5,
            lwd=8)
  }
  points(myPtsRot$X,myPtsRot$Y,col=col.plot,pch=19)
  graph2ppt(file='plot1.ppt',height = 5, width = 10)
  #后处理。
  #8AE1FC
  #smooth
  
  for (i in 1:length(PointsOfThisPeriod)) {
    line.now = as.matrix(PointsOfThisPeriod[[i]])
    line.smooth = smooth_ksmooth(line.now,smoothness = 3)
    lines(x = line.smooth[,1], 
          y = line.smooth[,2],
          col='orange',
          cex = 0.25,
          lwd= 25)
  }
  points(myPtsRot$X,myPtsRot$Y,col=col.plot,pch=19)
  graph2ppt(file='plot1.ppt',height = 5, width = 10, append = TRUE)
  
  
  