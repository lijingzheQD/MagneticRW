# function to compute distance between a point and a scatterplot-based curve
# x, y: coordinates of the point
# x_vals, y_vals: vectors of x and y values representing the curve
point_scatterplot_distance <- function(x, y, x_vals, y_vals) {
  # define a function to compute the distance between two points
  distance <- function(x1, y1, x2, y2) {
    sqrt((x2 - x1)^2 + (y2 - y1)^2)
  }
  
  # find the index of the x-coordinate in the curve that is closest to the point
  distances <- sapply(x_vals, function(x_val) distance(x, y, x_val, y_vals[x_vals == x_val]))
  if(is.list(distances)){distances = as.data.frame(distances)}
  min_distance <- min(distances)
  # min_index <- which(distances == min_distance)[1]
  # 
  # # compute the distance between the point and the closest point on the curve
  # distance(x, y, x_vals[min_index], y_vals[min_index])
}
# example
if(0){
  # define the x and y values of a scatterplot-based curve
  x_vals <- seq(-10, 10, length.out = 1000)#x_vals = xs
  y_vals <- x_vals^2#y_vals = ys
  plot(x_vals,y_vals,xlim = c(-5,5),ylim = c(0,15));points(1,2,col=6,pch=19)
  # compute the distance between the point (1, 2) and the scatterplot-based curve
  point_scatterplot_distance(1, 2, x_vals, y_vals)
}